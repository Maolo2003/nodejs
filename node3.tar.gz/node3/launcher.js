const { name } = require("ejs");
const exp = require("express");
const path = require("path");
const app = exp();
const logger = require("morgan")

app.set("view engine","ejs");
app.set("views", path.join(__dirname, "./views"));

app.use(exp.static(path.join(__dirname, "./static"))); // sirve para renderizar un html estatico

app.get("/saludar", (req, res)=>{
    let nombreCompleto = "jose repelin cuchara";

   

    res.render("paginas/saludar", {
        "nombre": nombreCompleto
    });
});

app.get("/catalogo", (req,res)=>{
    fetch('https://fakestoreapi.com/products')
            .then(res=>res.json())
            .then(json=>{
                console.log(json)
        const productosDiv = document.getElementById('productos');
  
        data.forEach((producto) => {
          const carta = document.createElement('div');
          carta.className = 'carta';
          carta.innerHTML = `
            <p><strong>Price:</strong> $${producto.price}</p>
            <p><strong>Category:</strong> ${producto.category}</p>
            <p><strong>Rating:</strong> ${producto.rating.rate} (based on ${producto.rating.count} ratings)</p>
            <img src="${producto.image}" alt="${producto.title}" />
            <br> <br>
            <button class="agregarCarrito" onclick="agregaralcarro()">Agregar al carrito</button> <!-- Botón dentro de la carta -->
          `;
          productosDiv.appendChild(carta);
        });
      });
      res.render('paginas/catalogo', {
        
    }); 
            });
            


app.get("/listardepartamentos", (req,res)=>{
    fetch("https://api-colombia.com/api/v1/Department")
    .then(response => response.json())
    .then(data => {
        console.log(data);
        
        res.render('paginas/listar', {
            listardepartamentos: data
        });

    });

});


app.get("/", (req, res)=>{
    res.send("<h3>Hola Mao</h3>");
});


app.listen(9090, ()=>{
    console.log("Servidor en linea");
});

